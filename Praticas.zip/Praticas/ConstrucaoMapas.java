import java.lang.*;
public class ConstrucaoMapas{
  public static Scanner userin = new Scanner(system.in);
  public static void main() {
    static int n_nos, n_percurso;
    n_nos = userin.Next();
    n_percurso = userin.Next(); userin.nextLine();
    
  }
}
